<footer class="db-footer">
    <div class="container">
      <div class="row">
        <div class="col-md-7 social-icons-list">
          <a  href="https://www.facebook.com/dunesberry" target="_blank"><img src="{{asset('assets/images/social media icons-01.png')}}"
               /></a>
          <a  href="https://www.instagram.com/dunesberry/" target="_blank"><img
              src="{{asset('assets/images/social media icons-02.png')}}"  /></a>
          <a  href="https://www.linkedin.com/company/dunesberry/" target="_blank"><img
              src="{{asset('assets/images/social media icons-06.png')}}" /></a>
          <a href="https://twitter.com/dunesberryworld" target="_blank"><img src="{{asset('assets/images/social media icons-08.png')}}"
             /></a>
          <!--<a  href="https://www.tiktok.com/@dunesberry.sa" target="_blank"><img src="{{asset('assets/images/social media icons-05.png')}}"-->
          <!--   /></a>-->
          <!--<a  href="https://www.youtube.com/user/dunesberryvision" target="_blank"><img-->
          <!--    src="{{asset('assets/images/social media icons-04.png')}}"  /></a>-->
          <a href="https://wa.me/966570326919?text=" target="_blank">
            <img src="{{asset('assets/images/social media icons-03.png')}}" /></a>
          <a  href="tel:+966570326919" target="_blank"><img src="{{asset('assets/images/social media icons-09.png')}}"  /></a>
        </div>
        <div class="col-md-5 d-flex justify-content-end">
          <!-- <button class="db-button">View</button> -->
          <p class="mx-4 my-auto ">{{__('genral.DunesberryProfile')}}</p>
          <a href="https://www.dunesberry.com/brochures/dunesberry.pdf" class="db-button py-3" target="_blank">{{__('genral.View')}}</a>
        </div>
      </div>
    </div>
  </footer>